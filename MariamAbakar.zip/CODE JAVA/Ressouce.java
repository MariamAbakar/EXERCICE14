
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Ressouce {

    /**
     * Default constructor
     */
    public Ressouce() {
    }

    /**
     * 
     */
    public void Type;

    /**
     * 
     */
    public void Quantité;

    /**
     * 
     */
    public void Disponibilité;

    /**
     * 
     */
    public void Ajouter() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Supprimer() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Verifier() {
        // TODO implement here
    }

}