
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Probleme Decision {

    /**
     * Default constructor
     */
    public Probleme Decision() {
    }

}