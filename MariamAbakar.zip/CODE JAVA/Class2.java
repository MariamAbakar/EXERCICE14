
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Class2 {

    /**
     * Default constructor
     */
    public Class2() {
    }

}