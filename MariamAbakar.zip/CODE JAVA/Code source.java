
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Code source extends Produit {

    /**
     * Default constructor
     */
    public Code source() {
    }

    /**
     * 
     */
    public void Fichier;

    /**
     * 
     */
    public void Langage;

    /**
     * 
     */
    public void Version;

}