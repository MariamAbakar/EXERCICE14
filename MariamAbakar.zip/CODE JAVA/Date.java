
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Date {

    /**
     * Default constructor
     */
    public Date() {
    }

    /**
     * 
     */
    public void Date affectation;

}