
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Outil materiel extends Ressouce {

    /**
     * Default constructor
     */
    public Outil materiel() {
    }

    /**
     * 
     */
    public bool Partageable;

    /**
     * 
     */
    public void Prix;

    /**
     * 
     */
    public void Quantité;

    /**
     * 
     */
    public void Entretenir() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Remplacer() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Utiliser() {
        // TODO implement here
    }

}