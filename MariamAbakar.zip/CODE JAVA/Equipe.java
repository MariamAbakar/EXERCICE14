
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Equipe {

    /**
     * Default constructor
     */
    public Equipe() {
    }

    /**
     * 
     */
    public void id_equipe;

    /**
     * 
     */
    public void Attribute1;

}