
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Rendement {

    /**
     * Default constructor
     */
    public Rendement() {
    }

    /**
     * 
     */
    public void Efficacité;

    /**
     * 
     */
    public void Mesure;

    /**
     * 
     */
    public void Afficher() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Calcul() {
        // TODO implement here
    }

    /**
     * 
     */
    public void uu() {
        // TODO implement here
    }

}