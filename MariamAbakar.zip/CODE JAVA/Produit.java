
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Produit {

    /**
     * Default constructor
     */
    public Produit() {
    }

    /**
     * 
     */
    public void Nom;

    /**
     * 
     */
    public void Prix;

    /**
     * 
     */
    public void Quantité Stock;

    /**
     * 
     */
    public void Date création;

    /**
     * 
     */
    public void jh;

    /**
     * 
     */
    public void CalculValeurStock() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Mettre ajourStock() {
        // TODO implement here
    }

    /**
     * 
     */
    public void AfficherDetails() {
        // TODO implement here
    }

}