
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Cahier de charge extends Produit {

    /**
     * Default constructor
     */
    public Cahier de charge() {
    }

    /**
     * 
     */
    public void Exigence;

    /**
     * 
     */
    public void Contraintes;

    /**
     * 
     */
    public void Objectifs;

    /**
     * 
     */
    public void Valider() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Mettre à Jour() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Archiver() {
        // TODO implement here
    }

}