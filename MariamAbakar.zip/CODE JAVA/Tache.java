
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Tache {

    /**
     * Default constructor
     */
    public Tache() {
    }

    /**
     * 
     */
    public void Intitulé;

    /**
     * 
     */
    public void Description;

    /**
     * 
     */
    public void Date prévue() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Date effective() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Date terminé() {
        // TODO implement here
    }

}