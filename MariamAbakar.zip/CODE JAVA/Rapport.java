
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Rapport {

    /**
     * Default constructor
     */
    public Rapport() {
    }

    /**
     * 
     */
    public void Titre_rap;

    /**
     * 
     */
    public void Date creation_rap;

    /**
     * 
     */
    public void Auteur_rap;

    /**
     * 
     */
    public void Projet;

    /**
     * 
     */
    public void Generer Rapport() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Afficher() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Destinataire() {
        // TODO implement here
    }

}