
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Periode {

    /**
     * Default constructor
     */
    public Periode() {
    }

    /**
     * 
     */
    public void Date début;

    /**
     * 
     */
    public void Date fin;

    /**
     * 
     */
    public void Durée;

    /**
     * 
     */
    public void Calcul durée() {
        // TODO implement here
    }

    /**
     * 
     */
    public void La periode() {
        // TODO implement here
    }

}