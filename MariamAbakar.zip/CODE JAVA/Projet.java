
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Projet {

    /**
     * Default constructor
     */
    public Projet() {
    }

    /**
     * 
     */
    public void Nom_projet;

    /**
     * 
     */
    public void Date debut;

    /**
     * 
     */
    public void date fin;

    /**
     * 
     */
    public void Attribute1;

    /**
     * 
     */
    public void Demarrer() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Calcule avancement() {
        // TODO implement here
    }

}