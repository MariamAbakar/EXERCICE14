
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Agent extends Ressouce {

    /**
     * Default constructor
     */
    public Agent() {
    }

    /**
     * 
     */
    public void Matricule_agent;

    /**
     * 
     */
    public void Nom_agent;

    /**
     * 
     */
    public void Date naissance;

    /**
     * 
     */
    public void Date recrutement() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Qualification() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Domaine expertice() {
        // TODO implement here
    }

}