
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Outil logiciel {

    /**
     * Default constructor
     */
    public Outil logiciel() {
    }

    /**
     * 
     */
    public void Nom;

    /**
     * 
     */
    public void type;

    /**
     * 
     */
    public void version;

    /**
     * 
     */
    public void licence;

    /**
     * 
     */
    public void demarrer() {
        // TODO implement here
    }

    /**
     * 
     */
    public void mettreajour() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Afficher Details() {
        // TODO implement here
    }

}