
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Doc conception extends Produit {

    /**
     * Default constructor
     */
    public Doc conception() {
    }

    /**
     * 
     */
    public void Titre;

    /**
     * 
     */
    public void Version;

    /**
     * 
     */
    public void Auteur;

    /**
     * 
     */
    public void Contenu;

    /**
     * 
     */
    public void MettreàJour() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Afficher() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Archiver() {
        // TODO implement here
    }

}