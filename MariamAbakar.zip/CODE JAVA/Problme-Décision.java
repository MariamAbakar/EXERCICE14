
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Problme-Décision {

    /**
     * Default constructor
     */
    public Problme-Décision() {
    }

    /**
     * 
     */
    public void Probleme;

    /**
     * 
     */
    public void Options;

    /**
     * 
     */
    public void Décision;

    /**
     * 
     */
    public void Evaluer() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Prendre Décision() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Afficher Probleme() {
        // TODO implement here
    }

}