
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Réunion extends Class2 {

    /**
     * Default constructor
     */
    public Réunion() {
    }

    /**
     * 
     */
    public void DateHeure;

    /**
     * 
     */
    public void Lieu;

    /**
     * 
     */
    public void Participants;

    /**
     * 
     */
    public void Sujet;

    /**
     * 
     */
    public void Durer;

    /**
     * 
     */
    public void Ajouter participants() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Planifier() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Annuler() {
        // TODO implement here
    }

}