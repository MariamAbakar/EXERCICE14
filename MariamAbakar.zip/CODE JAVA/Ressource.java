
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Ressource {

    /**
     * Default constructor
     */
    public Ressource() {
    }

}