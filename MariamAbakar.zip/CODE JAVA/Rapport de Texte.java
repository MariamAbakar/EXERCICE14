
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Rapport de Texte extends Produit {

    /**
     * Default constructor
     */
    public Rapport de Texte() {
    }

    /**
     * 
     */
    public void Titre;

    /**
     * 
     */
    public void Auteur;

    /**
     * 
     */
    public void Contenu;

    /**
     * 
     */
    public void Date Création;

    /**
     * 
     */
    public void Generer Texe() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Afficher() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Destinaire() {
        // TODO implement here
    }

}